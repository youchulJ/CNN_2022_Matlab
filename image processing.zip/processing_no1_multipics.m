%% 분광사진을 alignment 시켜주는 작업과 동시에 reflectance를 구해주는 작업 - 첫번째 단계 ! 

close all; clear all; clc;

%cd('C:\Users\User\Desktop\연안실습_드론_자료\1번 사진'); %이미지 불러올 경로 %n번 사진 n=1~3

cd('H:\2022 대학원\reagain\test1\0001\original');

%% 1. WV 오름차순 순서를 찾기 
iname = ls('*.tif');
for i=1:10                                              %메타데이터 내의 밴드의 중앙파장대를 찾아 파일의 순서와 다른 파장대의 
    meta = Lee_RedEdge_MX_metadata_read(iname(i,:));    %순서를 다시 알맞게 파장대의 순서대로 정렬한다.
    wv(i) = meta(33,2);
end
[B, I] = sort(wv)                                       %다음을 통해 파장대의 진짜 순서를 알게함 I가 실제 파장대로 들어가야하는 번호임 

%% 2. Radiance_Irradiance + reflectance

for i=1:10
    [radiance irradiance] = Lee_RedEdge_MX_image_to_radiance_irradiance(iname(I(i),:)); %radiance, irradiance 구하는 함수
    reflectance=radiance./irradiance; %reflectance 구하는 식
    Reflectance(:,:,i)=reflectance; %10개 밴드의 reflectance stacking
end

%% 3. Image Registration & crop
[registerd_crop] = Lee_RedEdge_Dual_alignment_mat(Reflectance); %registration과 동일영역 crop 함수

%cd('H:\2022 대학원\reagain\test1\0001\reflectance');
save('Reflectance_Image0004.mat','registerd_crop'); %n번 이미지 n=1~3 크롭된 reflectance를 저장해준다.

%=================================pre processing===================================================

%% 참고
% alignment시 원본 사진의 registration & crop을 하기 전에 사진끼리의 공통점들이 있는 사진을 사용하는 것이
% 맞다. 전체적인 순서로는 가지고 있는 사진을 쭉 다 불러와 밴드의 순서에 맞게 stacking을 한뒤, radiance,
% irradiace를 계산해 reflectance를 구해주게 되고 그 다음과정의 reflectance를 registerd_crop으로
% 다시금 저장해주는 과정이다. 결론적으로 내가 사용해야 할 reflectance.mat은 crop된 이미지가 들어간 것.
