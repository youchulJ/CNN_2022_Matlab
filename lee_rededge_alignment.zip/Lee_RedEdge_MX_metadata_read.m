function [metadata] = Lee_RedEdge_MX_metadata_read(image_name)

% image_name = im_dir{i,1};

currentFolder = pwd;
copyfile('H:\2022 대학원\reagain\test1\0001\original\exiftool.exe', currentFolder)
% image_name = [station_path(i,1:end-5), num2str(j),'.tif'];

meta = getexif(image_name);
sz = size(meta);

if strcmp(meta(1:14), 'File not found')
    metadata = NaN;
else

    k = 1;
    for i = 1:sz(2);
        if sz(2) == i;

        else
            if meta(i:i+1) == ': ';
                coor(k) = i;
                k = k + 1;    
            end
        end
    end
    coor = coor(:,1:end-1);
    sz2 = size(coor);
    for i = 1:sz2(2);
        if sz2(2) == i;
                metadata{i, 1} = strtrim(meta(coor(i)-32 : coor(i)-1));
                metadata{i, 2} = meta(coor(i)+1 : end);
        else
            metadata{i, 1} = strtrim(meta(coor(i)-32 : coor(i)-1));
            metadata{i, 2} = meta(coor(i)+1 : coor(i+1)-33);
        end
    end
    
end
    
end