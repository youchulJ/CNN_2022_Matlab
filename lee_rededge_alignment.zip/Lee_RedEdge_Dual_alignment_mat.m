function [registerd_crop] = Lee_RedEdge_Dual_alignment_mat(data)
% data = RedEdge 데이터 5개가 쌓여있는 (:,:,1:5) 형태의 자료여야 함
% 자료는 RedEdge가 기본적으로 제공하는 번호 순서대로 쌓여야 함
% Blue Green Red NIR Rededge / 여기서 RedEdge가 센터 카메라(5번) = fixed

%% image alignment
 FIXED = data(:,:,4);
 data(:,:,4) = [];
for j=1:9
    MOVING = data(:,:,j);

    fixedRefObj = imref2d(size(FIXED));
    movingRefObj = imref2d(size(MOVING));

    % Phase correlation
    tform = imregcorr(MOVING,movingRefObj,FIXED,fixedRefObj,'transformtype','translation','Window',true);
    MOVINGREG.Transformation = tform;
    MOVINGREG.RegisteredImage = imwarp(MOVING, movingRefObj, tform, 'OutputView', fixedRefObj, 'SmoothEdges', true);

    % Store spatial referencing object
    MOVINGREG.SpatialRefObj = fixedRefObj;

    registerd(:,:,j) = MOVINGREG.RegisteredImage;
end
    registerd(:,:,5:10) = registerd(:,:,4:9);
    registerd(:,:,4) = FIXED;

%% align 자료 crop 하기
for i=1:10
    dt = registerd(:,:,i);
    coor = find(dt==0);
    registerd(coor) = 0;
%     figure, pcolor(dt), shading flat
    for j=1:10
        dt2 = registerd(:,:,j);
        dt2(coor) = 0;
        registerd(:,:,j) = dt2;        
    end
end

for i=1:10
    okind=find(dt2>0);
    [ii,jj]=ind2sub(size(dt2),okind);
    ymin=min(ii);ymax=max(ii);xmin=min(jj);xmax=max(jj);
    registerd_crop(:,:,i)=imcrop(registerd(:,:,i),[xmin,ymin,xmax-xmin+1,ymax-ymin+1]);
end

% figure, pcolor(registerd_crop(:,:,5)), shading flat

end