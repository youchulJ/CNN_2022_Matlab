function [DGm RCm time] = Lee_RedEdge_MX_metadata_extractor(meta);
% version 1.0 / made by Lee
% version 2.0 / modified on 2020.09.02 / meta 안에 있는 정보들의 위치를 자동으로 찾도록 수정

% DGm = {roll pitch yaw lat lon alt FL Fv Fh Fd SS};
% RCm = {irra radm vigc vigp exti isos bklv};
% 레드엣지의 메타데이터에서 특정 변수를 추출하는 코드
% Lee_RedEdge_metadata_extractor(메타데이터);
% 'Lee_RedEdge_metadata_collector'에서 산출된 산출물의 각 셀(cell)에 적용 가능(105*2)
%%% 입력변수 설명(각 변수의 '약어'가 function의 string으로 입력되어야 함
% radm = radiomatric calibration coefficient    / number = 32 /
% vigc = vignette center                        / number = 41 /
% vigp = vignette polymal                       / number = 42 /
% irra = Irradiance                             / number = 50 / DLS로 관측된 방사조도
% exti = expouse time                           / number = 70 /
% bklv = blacklevel                             / number = 90 /
% isos = ISO speed (pbl)                        / number = 73 /
% roll = roll                                   / number = 55 /
% pitch = pitch                                 / number = 54 /
% yaw = yaw                                     / number = 53 /
% alt = altitude                                / number = 93 /
% lon = longitude                               / number = 94 /
% lat = latitude                                / number = 95 /
% time = time                                   / number = 28 / ModifyDate
% folg = focal lenght                           / number = 78 / 

% 예제
% load RE_181024_SMG_North_East_meta_sur.mat
% meta = RE_181024_SMG_North_East_meta_sur{1};
% variable = 'irra';
% meta = RE_meta_NE_sky(:,:,701);

N = 65536; % 16 bit
%% Direct Georeferencing metadata
idx = all(ismember(cellstr(char(meta(:,1))), 'IrradianceYaw'),2);
if size(idx,1) < 95 % DLS 데이터가 있고 없고의 기준값, 일단은 임의의 값임 (없을 때 85, 있을 때 105)
    yaw = NaN;
    pitch = NaN;
    roll = NaN;
    alt = NaN;
    lon = NaN;
    lat = NaN;
else

    idx = all(ismember(cellstr(char(meta(:,1))), 'IrradianceYaw'),2);
    idx = find(idx == 1);
    yaw = str2num(cell2mat(meta(idx, 2)));

    idx = all(ismember(cellstr(char(meta(:,1))), 'IrradiancePitch'),2);
    idx = find(idx == 1);
    pitch = str2num(cell2mat(meta(idx, 2))); %-40; % 왜 - 40을 하는가? / 현재는 수정, -40 하지 않았음

    idx = all(ismember(cellstr(char(meta(:,1))), 'IrradianceRoll'),2);
    idx = find(idx == 1);
    roll = str2num(cell2mat(meta(idx, 2)));

    idx = all(ismember(cellstr(char(meta(:,1))), 'GPSAltitude'),2);
    idx = find(idx == 1);
    alt = meta(idx,2);
    alt = regexp(cell2str(alt), ' ', 'split');
    alt = str2num(alt{2});

    idx = all(ismember(cellstr(char(meta(:,1))), 'GPSLongitude'),2);
    idx = find(idx == 1);
    lon = meta(idx,2);
    lon = regexp(cell2str(lon), ' ', 'split');
    lon = dms2degrees([str2num(cell2mat(lon(2))), str2num(cell2mat(lon(4))), str2num(lon{5}(1:end-2))]);

    idx = all(ismember(cellstr(char(meta(:,1))), 'GPSLatitude'),2);
    idx = find(idx == 1);
    lat = meta(idx,2);
    lat = regexp(cell2str(lat), ' ', 'split');
    lat = dms2degrees([str2num(cell2mat(lat(2))), str2num(cell2mat(lat(4))), str2num(lat{5}(1:end-1))]);
    
end

SS = [4.8000 3.6000];
FL = 5.4724;
Fv = 36.9000;
Fh = 47.9000;
Fd = 58.1000;


DGm = {roll pitch yaw lat lon alt SS FL Fv Fh Fd};

%% Radiometric calibration metadata
idx = all(ismember(cellstr(char(meta(:,1))), 'IrradianceYaw'),2);
if size(idx,1) < 95 % DLS 데이터가 있고 없고의 기준값, 일단은 임의의 값임 (없을 때 85, 있을 때 105)
    irra = NaN;
    radm = NaN;
    vigc = NaN;
    vigp = NaN;
    exti = NaN;
    isos = NaN;
    bklv = NaN;
    else
    idx = all(ismember(cellstr(char(meta(:,1))), 'Irradiance'),2);
    idx = find(idx == 1);
    irra = meta(idx,2);
    irra = str2num(cell2mat(irra(1)));

    idx = all(ismember(cellstr(char(meta(:,1))), 'RadiometricCalibration'),2);
    idx = find(idx == 1);
    radm = meta(idx,2);
    radm = strsplit(char(radm(1)), ',');
    radm = [str2num(cell2mat(radm(1))) str2num(cell2mat(radm(2))) str2num(cell2mat(radm(3)))];

    idx = all(ismember(cellstr(char(meta(:,1))), 'VignettingCenter'),2);
    idx = find(idx == 1);
    vigc = meta(idx,2);
    vigc = strsplit(char(vigc(1)), ',');
    vigc = [str2num(cell2mat(vigc(1))) str2num(cell2mat(vigc(2)))];

    idx = all(ismember(cellstr(char(meta(:,1))), 'VignettingPolynomial'),2);
    idx = find(idx == 1);
    vigp = meta(idx,2);
    vigp = strsplit(char(vigp(1)), ',');
    vigp = [str2num(cell2mat(vigp(1))) str2num(cell2mat(vigp(2))) str2num(cell2mat(vigp(3)))...
        str2num(cell2mat(vigp(4))) str2num(cell2mat(vigp(5))) str2num(cell2mat(vigp(6)))];

    idx = all(ismember(cellstr(char(meta(:,1))), 'ExposureTime'),2);
    idx = find(idx == 1);
    exti = meta(idx,2);
    exti = strsplit(char(exti(1)), ',');
    exti = [str2num(cell2mat(exti(1)))];

    idx = all(ismember(cellstr(char(meta(:,1))), 'ISOSpeed'),2);
    idx = find(idx == 1);
    isos = meta(idx,2);
    isos = strsplit(char(isos(1)), ',');
    isos = [str2num(cell2mat(isos(1)))];
    isos =  isos/100; % gain : ISOspeed/100

    idx = all(ismember(cellstr(char(meta(:,1))), 'BlackLevel'),2);
    idx = find(idx == 1);
    bklv = meta(idx,2);
    bklv = strsplit(char(bklv(1)), ' ');
    bklv = [str2num(cell2mat(bklv(2))) str2num(cell2mat(bklv(3))) str2num(cell2mat(bklv(4))) str2num(cell2mat(bklv(5)))];
    bklv = mean(bklv/N); % ??????????????????????
end

RCm = {irra radm vigc vigp exti isos bklv};

%% time
idx = all(ismember(cellstr(char(meta(:,1))), 'IrradianceYaw'),2);
if size(idx,1) < 95 % DLS 데이터가 있고 없고의 기준값, 일단은 임의의 값임 (없을 때 85, 있을 때 105)
    T = NaN;
    time = NaN;
else
    idx = all(ismember(cellstr(char(meta(:,1))), 'ModifyDate'),2);
    idx = find(idx == 1);
    T = cell2mat(meta(idx,2));
    time(1) = str2num(T(2:5));
    time(2) = str2num(T(7:8));
    time(3) = str2num(T(10:11));
    time(4) = str2num(T(13:14));
    time(5) = str2num(T(16:17));
    time(6) = str2num(T(19:20));
end

end