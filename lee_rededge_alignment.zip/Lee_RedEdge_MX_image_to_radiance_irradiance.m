function [radiance irradiance] = Lee_RedEdge_MX_image_to_radiance_irradiance(image_name);
% version 1.0 / 
% version 2.0 / 2020.09.04 / DLS 끊김으로 메타 없는경우 및 영상이 깨지는 경우를 보완
%% 설명
% RedEdge 이미지의 디지털 넘버를 조도(radiance)로 바꿔주는 함수.
% 비네트 모델 계산이 포함되어 있음.
% 이미지가 있는 폴더 내에서 run 시켜야 하며, 'exiftool.exe'를 따로 복사 할 필요 없음.
% 이미지 및 메타데이터에서 데이터를 추출하여 자동으로 radiance를 계산
% Input: 
% - image_name: 이미지의 이름(str)
%
% image_name = 'IMG_0000_1.tif';
% image_name = 'IMG_0000_2.tif';

%% 이미지 데이터 불러오기
if size(importdata(image_name),1) == 960 % 가끔 이미지가 깨져서 open이 안되는 경우가 있는걸 고려
image = imread(image_name);

%% 메타데이터 불러오기
meta = Lee_RedEdge_MX_metadata_read(image_name);
[DGm RCm time] = Lee_RedEdge_MX_metadata_extractor(meta);

irra = RCm{1};
radm = RCm{2};
vigc = RCm{3};
vigp = RCm{4};
exti = RCm{5};
isos = RCm{6};
bklv = RCm{7};

if isnan(irra) == 1
    
    radiance = NaN;
    irradiance = NaN;
else
    %% 비네트(vinette) 모델 계산
    N = 65536; % 16 bit
    x = 1:1280; %
    y = 1:960;
    [y x] = meshgrid(x,y);

    r = sqrt((((x-vigc(2)).^2)+(y-vigc(1)).^2)); %(1) = column, 행, (2) = row, 열
    k = 1+(vigp(1).*r)+(vigp(2).*(r.^2))+(vigp(3).*(r.^3))+(vigp(4).*(r.^4))+(vigp(5).*(r.^5))+(vigp(6).*(r.^6)); % correction factor by which the raw pixel value should be divided to correct for vignette
    p = double(image)./(N); % normalized raw pixel value

    %% 조도(radiance) 계산
    radiance = (radm(1)/isos).*((p-bklv)./(exti+(radm(2).*x)-(radm(2)*exti.*x))).*(1./k);
    irradiance = irra;

end
else
    radiance = NaN;
    irradiance = NaN;
end
